# Changelog

## Version 0.5.116

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 6 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 36 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 192 |


# Changelog

## Version 0.5.115

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 5 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 90 |
| Style changes/Improvements | 6 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.114

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 3 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 484 |


# Changelog

## Version 0.5.113

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 10 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 32 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.112

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 9 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 40 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 1 |


# Changelog

## Version 0.5.111

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 44 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 185 |
| Style changes/Improvements | 1 |
| Files Renamed | 33 |
| Files Deleted | 76 |


# Changelog

## Version 0.5.110

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 36 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.109

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 21 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.108

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 3 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.107

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 176 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 319 |
| Style changes/Improvements | 6 |
| Files Renamed | 26 |
| Files Deleted | 814 |


# Changelog

## Version 0.5.106

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 22 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.105

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 22 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.104

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 176 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 314 |
| Style changes/Improvements | 6 |
| Files Renamed | 26 |
| Files Deleted | 814 |


# Changelog

## Version 0.5.103

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 176 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 314 |
| Style changes/Improvements | 6 |
| Files Renamed | 26 |
| Files Deleted | 814 |


# Changelog

## Version 0.5.102

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 386 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 307 |
| Style changes/Improvements | 5 |
| Files Renamed | 26 |
| Files Deleted | 811 |


# Changelog

## Version 0.5.101

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 11 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.100

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 386 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 307 |
| Style changes/Improvements | 5 |
| Files Renamed | 26 |
| Files Deleted | 811 |


# Changelog

## Version 0.5.99

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 386 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 307 |
| Style changes/Improvements | 5 |
| Files Renamed | 26 |
| Files Deleted | 811 |


# Changelog

## Version 0.5.98

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 385 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 307 |
| Style changes/Improvements | 5 |
| Files Renamed | 26 |
| Files Deleted | 811 |


# Changelog

## Version 0.5.97

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 385 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 307 |
| Style changes/Improvements | 5 |
| Files Renamed | 26 |
| Files Deleted | 811 |


# Changelog

## Version 0.5.96

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 43 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.95

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 27 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.94

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 68 |
| Style changes/Improvements | 1 |
| Files Renamed | 2 |
| Files Deleted | 645 |


# Changelog

## Version 0.5.93

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 385 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 298 |
| Style changes/Improvements | 4 |
| Files Renamed | 27 |
| Files Deleted | 167 |


# Changelog

## Version 0.5.92

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 385 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 297 |
| Style changes/Improvements | 4 |
| Files Renamed | 27 |
| Files Deleted | 167 |


# Changelog

## Version 0.5.91

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 385 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 297 |
| Style changes/Improvements | 4 |
| Files Renamed | 27 |
| Files Deleted | 167 |


# Changelog

## Version 0.5.90

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 1 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 19 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 110 |


# Changelog

## Version 0.5.89

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 490 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 307 |
| Style changes/Improvements | 4 |
| Files Renamed | 9 |
| Files Deleted | 163 |


# Changelog

## Version 0.5.88

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 114 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 296 |
| Style changes/Improvements | 4 |
| Files Renamed | 9 |
| Files Deleted | 164 |


# Changelog

## Version 0.5.87

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 17 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.86

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 34 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.85

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 114 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 292 |
| Style changes/Improvements | 4 |
| Files Renamed | 9 |
| Files Deleted | 164 |


# Changelog

## Version 0.5.84

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 114 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 292 |
| Style changes/Improvements | 4 |
| Files Renamed | 9 |
| Files Deleted | 164 |


# Changelog

## Version 0.5.83

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 114 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 291 |
| Style changes/Improvements | 4 |
| Files Renamed | 9 |
| Files Deleted | 164 |


# Changelog

## Version 0.5.82

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 11 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 21 |
| Style changes/Improvements | 2 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.81

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 27 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 46 |
| Style changes/Improvements | 0 |
| Files Renamed | 1 |
| Files Deleted | 3 |


# Changelog

## Version 0.5.80

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 76 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 288 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 161 |


# Changelog

## Version 0.5.79

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 24 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.78

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 4 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.77

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 32 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.76

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 13 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.75

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 4 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.74

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 23 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 1 |


# Changelog

## Version 0.5.73

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 66 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 276 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 161 |


# Changelog

## Version 0.5.72

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 1 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.71

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 66 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 274 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 161 |


# Changelog

## Version 0.5.70

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 65 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 270 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 161 |


# Changelog

## Version 0.5.69

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 65 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 270 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 161 |


# Changelog

## Version 0.5.68

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 65 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 268 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 161 |


# Changelog

## Version 0.5.67

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 1 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 6 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 1 |


# Changelog

## Version 0.5.66

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 64 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 256 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.65

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 64 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 256 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.64

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 16 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.63

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 16 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.62

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 64 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 253 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.61

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 64 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 253 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.60

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 18 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.59

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 64 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 247 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.58

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 241 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.57

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 241 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.56

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 241 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.55

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 239 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.54

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 236 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.53

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 231 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.52

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 231 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.51

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 229 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.50

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 229 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.49

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 220 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 159 |


# Changelog

## Version 0.5.48

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 203 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 159 |


# Changelog

## Version 0.5.47

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 200 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 159 |


# Changelog

## Version 0.5.46

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 200 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 159 |


# Changelog

## Version 0.5.45

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 52 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 199 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 159 |


# Changelog

## Version 0.5.44

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 4 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.43

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 4 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 13 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.42

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 13 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.41

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 49 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 192 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.40

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 38 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.39

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 48 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 187 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.38

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 48 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 187 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.37

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 57 |
| Style changes/Improvements | 2 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.36

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 10 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.35

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 48 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 173 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.34

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 48 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 173 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.33

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 48 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 171 |
| Style changes/Improvements | 4 |
| Files Renamed | 8 |
| Files Deleted | 160 |


# Changelog

## Version 0.5.32

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 42 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 154 |
| Style changes/Improvements | 4 |
| Files Renamed | 1 |
| Files Deleted | 25 |


# Changelog

## Version 0.5.31

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 42 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 153 |
| Style changes/Improvements | 4 |
| Files Renamed | 1 |
| Files Deleted | 25 |


# Changelog

## Version 0.5.30

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 2 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.29

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 1 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.28

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 18 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.27

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 18 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.26

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 53 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.25

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 33 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.24

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 26 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 34 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.23

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 17 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 78 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.22

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 4 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 47 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.21

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 29 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.20

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 21 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.19

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 5 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.18

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 1 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.17

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 30 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.14

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 9 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 39 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.13

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 1 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.12

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 6 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.11

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 6 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.10

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 5 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.9

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 17 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.8

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 6 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.7

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 19 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.6

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 13 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 16 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.5

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 29 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.4

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 8 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 12 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.3

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 20 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 22 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.2

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 8 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 47 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.1

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 13 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.5.0

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 3 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 29 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.4.0

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 4 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 46 |
| Style changes/Improvements | 3 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.3.1

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 35 |
| Style changes/Improvements | 0 |
| Files Renamed | 1 |
| Files Deleted | 0 |


# Changelog

## Version 0.3.0

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 4 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 40 |
| Style changes/Improvements | 3 |
| Files Renamed | 25 |
| Files Deleted | 1 |


# Changelog

## Version 0.2.3

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 16 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.2.2

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 21 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.2.1

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 21 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.2.0

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 9 |
| Style changes/Improvements | 1 |
| Files Renamed | 0 |
| Files Deleted | 0 |


# Changelog

## Version 0.1.0

| Category | Total Files |
| -------- | ----------- |
| New Module Files | 0 |
| New UI Component Files | 0 |
| Bug fix/Improvement | 3 |
| Style changes/Improvements | 0 |
| Files Renamed | 0 |
| Files Deleted | 1 |


