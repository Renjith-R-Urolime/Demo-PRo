import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-settings-section',
  templateUrl: './employee-settings-section.component.html',
  styleUrls: ['./employee-settings-section.component.scss']
})
export class EmployeeSettingsSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
