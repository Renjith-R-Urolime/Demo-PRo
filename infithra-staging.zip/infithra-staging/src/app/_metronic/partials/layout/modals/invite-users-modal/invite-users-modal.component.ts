import { Component } from '@angular/core';

@Component({
  selector: 'app-invite-users-modal',
  templateUrl: './invite-users-modal.component.html',
})
export class InviteUsersModalComponent {
  constructor() {}
}
