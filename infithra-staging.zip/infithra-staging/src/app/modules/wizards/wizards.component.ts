import { Component } from '@angular/core';

@Component({
  selector: 'app-wizards',
  templateUrl: './wizards.component.html',
})
export class WizardsComponent {
  constructor() {}

}
