const express = require('express');
const expressStaticGzip = require('express-static-gzip');
const path = require('path');

const app = express();

// Enable gzip compression for server responses
app.use(expressStaticGzip(path.join(__dirname, 'dist', 'infithra'), {
  enableBrotli: true,
  orderPreference: ['br', 'gz'],
  setHeaders: (res) => {
    res.setHeader('Cache-Control', 'public, max-age=31536000');
  },
}));

// Catch all other routes and serve the Angular app's index.html
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'infithra', 'index.html'));
  });


// Start the server on port 5200
const PORT = 5200;
app.listen(PORT, () => {
  console.log(`App running at http://localhost:${PORT}/`);
});